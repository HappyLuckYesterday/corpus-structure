from espnet2.gan_svs.vits.vits import VITS  # NOQA
