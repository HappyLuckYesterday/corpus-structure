from espnet2.gan_codec.funcodec.funcodec import FunCodec
