from espnet2.gan_codec.hificodec.hificodec import HiFiCodec
